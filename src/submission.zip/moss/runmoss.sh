#! /bin/bash
PATH_TO_BASE = ""
PATH_TO_SUBMISSIONS = ""

moss -l csharp -b PATH_TO_BASE PATH_TO_SUBMISSIONS
